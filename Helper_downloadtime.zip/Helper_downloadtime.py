

toolbar_helper = '''

MDToolbar:
    title: "Download Time APP"

'''


speed_helper = '''

MDTextField:
	hint_text: "Enter the Download Speed"
	helper_text: "Mb/s"
	helper_text_mode: "on_focus"
	icon_right: "arrow-down-bold-outline"
	icon_right_color: app.theme_cls.primary_color
	pos_hint: {"center_x":0.5, "center_y":0.6}
	size_hint_x: None
	width: 300


'''

size_helper = '''

MDTextField:
	hint_text: "Enter the size of the file"
	helper_text: "Gb"
	helper_text_mode: "on_focus"
	icon_right: "image-size-select-small"
	icon_right_color: app.theme_cls.primary_color
	pos_hint: {"center_x":0.5, "center_y":0.5}
	size_hint_x: None
	width: 300


'''


