from kivymd.app import MDApp
from kivymd.uix.label import MDLabel, MDIcon
from kivymd.uix.screen import Screen
from kivymd.uix.button import MDFlatButton, MDRectangleFlatButton, MDIconButton, MDFloatingActionButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.dialog import MDDialog
from kivy.lang import Builder


from Helper_downloadtime import speed_helper, size_helper, toolbar_helper





class Download_TimeApp(MDApp):

	def build(self):
		self.theme_cls.primary_palette = "Blue"
		self.theme_cls.primary_hue = "500"
		self.theme_cls.theme_style = "Light"

		screen = Screen()


		self.toolbar = Builder.load_string(toolbar_helper)
		screen.add_widget(self.toolbar)


		self.speed = Builder.load_string(speed_helper)
		screen.add_widget(self.speed)

		self.size = Builder.load_string(size_helper)
		screen.add_widget(self.size)

		btn_flat = MDRectangleFlatButton(text="Show", pos_hint={"center_x":0.5, "center_y":0.4}, on_release=self.show_data)
		screen.add_widget(btn_flat)

	
		

		return screen

	def show_data(self, obj):
		
		if self.speed.text is "" or self.size.text is "":
			check_string = "Please enter all the information needed"

##################################################################################################################################################################		
		else:
			velocidade = float(self.speed.text)
			armazenamento_gigabites = float(self.size.text)
			armazenamento_megabites = armazenamento_gigabites * 1000
			tempo_segundos_download = int(armazenamento_megabites / velocidade)
			tempo_minutos_download = int(tempo_segundos_download/60)
			tempo_minutos_download_str = str(tempo_minutos_download)

			if tempo_minutos_download > 60:
				tempo_horas_download = tempo_minutos_download/60
				tempo_horas_download_int = int(tempo_horas_download)
				tempo_horas_download_float = tempo_horas_download - tempo_horas_download_int
				tempo_horas_minutos_download = round(tempo_horas_download_float * 60)
				tempo_horas_minutos_download_str = str(tempo_horas_minutos_download)
				tempo_horas_download_int_str = str(tempo_horas_download_int)



				check_string = ("O Download irá demorar aproximadamente "+ tempo_horas_download_int_str+" h "+tempo_horas_minutos_download_str+" min" )
			if tempo_minutos_download < 60:
				check_string = ("O Download irá demorar aproximadamente "+ tempo_minutos_download_str+ " minutos")
##################################################################################################################################################################   				





		close_button = MDFlatButton(text="Close", on_release=self.close_dialog)
		self.dialog = MDDialog(title="Download Time", text=check_string, size_hint=(0.7, 1), buttons=[close_button])
		self.dialog.open()

	def close_dialog(self, obj):
		self.dialog.dismiss()

		










Download_TimeApp().run()
